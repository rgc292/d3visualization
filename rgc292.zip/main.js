var margin = {top: 10, right: 10, bottom: 40, left: 28},
    width = 900 - margin.left - margin.right,
    height = 500 - margin.top - margin.bottom;


// setup x 
var xValue = function(d) { return d[$('#sel-x').val()];}, 
    xScale = d3.scale.linear().range([0, width]), 
    xMap = function(d) { return xScale(xValue(d));}, 
    xAxis = d3.svg.axis().scale(xScale).orient("bottom");

// setup y
var yValue = function(d) { return d[$('#sel-y').val()];}, 
    yScale = d3.scale.linear().range([height, 0]),
    yMap = function(d) { return yScale(yValue(d));}, 
    yAxis = d3.svg.axis().scale(yScale).orient("left");

// setup fill color
var cValue = function(d) { return d.Manufacturer;},
    color = d3.scale.category10();

// add canvas
var svg = d3.select(".plot").append("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
  .append("g")
    .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

// add tooltip
var tooltip = $('#hovered');


d3.csv("car.csv", function(error, csv) { 
    if (error) return console.warn(error);
    data = csv
    console.log(data);
    
    for(key in data[0]) {
        
        if(key != "name" && key !="origin")
            $('<option />').val(key).html(key).appendTo('#sel-x,#sel-y');
    }

    
    data.forEach(function(d) {
        for(key in d){
            // remove name and origin as they are string
            if(key != "name" && key !="origin") {
                d[key] = parseFloat(d[key]);
            }
        }
    });

    // initialize X axis
    svg.append("g")
      .attr("class", "x axis")
      .attr("transform", "translate(0," + height + ")")
    .append("text")
      .attr("class", "label")
      .attr("x", width)
      .attr("y", -6)
      .style("text-anchor", "end");

    // initialize Y axis
    svg.append("g")
      .attr("class", "y axis")
    .append("text")
      .attr("class", "label")
      .attr("transform","rotate(-90)")
      .attr("y", 6)
      .attr("dy", ".71em")
      .style("text-anchor", "end");

    // add click
    $('#update').on("click",showGraph)
});

function showGraph() {


    
    svg.selectAll(".dot").data(data).exit();
    
    svg.selectAll("circle").remove();

    
    xScale.domain([d3.min(data, xValue)-1, d3.max(data, xValue)+1]);
    yScale.domain([d3.min(data, yValue)-1, d3.max(data, yValue)+1]);

        // change the x axis
    svg.transition().select(".x.axis") 
        .call(xAxis)
        .select('.label')
        .text($('#sel-x').val());
    // change the y axis
    svg.transition().select(".y.axis")
        .call(yAxis)
        .select('.label')
        .text($('#sel-y').val());


    // draw dots/ Updates dots
    svg.selectAll(".dot")
      .data(data)
      .enter()
      .append("circle")
      .filter(function(d) { 
        
        if( d["mpg"]>=parseFloat($("#mpg-min").val()) && d["mpg"]<=parseFloat($("#mpg-max").val()) ){ return true;} 
        return false; })
      .attr("class", "dot")
      .attr("r", 2.5)
      .attr("cx", function(d) {  return xScale(xValue(d));})
      .attr("cy", function(d) { return yScale(yValue(d));} )
      .style("color", function(d) { return color(cValue(d));}) 
      .on("mouseover", function(d) {
          tooltip.html(d["name"]);
      })
      .on("mouseout", function(d) {
          tooltip.html("");
      });

};


